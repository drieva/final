﻿namespace System
{
    internal class Forms
    {
    }
}